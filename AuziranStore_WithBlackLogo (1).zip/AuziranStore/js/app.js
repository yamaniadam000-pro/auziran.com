// AUZIRAN - Core Application Logic

// --- DATA ---
const PRODUCTS = [
    {
        id: 'p-moss',
        name: 'STRTN® POLAR TECH PRINTED HOODIE – Moss',
        price_current: 280,
        price_old: 399,
        description: 'Next-generation polar tech. Signature structural aesthetic combined with advanced thermal retention capabilities.',
        images: [
            'assets/images/QQ1.webp', 'assets/images/QQ2.webp', 'assets/images/QQ3.webp', 'assets/images/QQ4.webp', 'assets/images/QQ5.webp'
        ]
    },
    {
        id: 'p-pink',
        name: 'CRTV DEPT. HOODIE – Baby Pink',
        price_current: 280,
        price_old: 399,
        description: 'Premium heavyweight cotton blend hoodie. Oversized fit, dropped shoulders, and double-lined hood for maximum comfort.',
        images: [
            'assets/images/WW1.webp', 'assets/images/WW2.webp', 'assets/images/WW3.webp', 'assets/images/WW4.webp', 'assets/images/WW5.webp'
        ]
    },
    {
        id: 'p-black',
        name: 'STRTN® RHINESTONE HOODIE – Black',
        price_current: 280,
        price_old: 399,
        description: 'Streetwear staple re-engineered for luxury. Rhinestone detailing on high-quality 450gsm pure cotton fleece.',
        images: [
            'assets/images/XX1.webp', 'assets/images/XX2.webp', 'assets/images/XX3.webp', 'assets/images/XX4.webp', 'assets/images/XX5.webp'
        ]
    }
];

// --- APP STATE ---
const state = {
    currentView: 'home',
    activeProduct: null,
    galleryIndex: 0,
    selectedSize: null,
    menuOpen: false,
    cartOpen: false,
    cart: [],
    checkoutMode: 'direct', // 'direct' or 'cart'
    sliderInterval: null,
    cardIntervals: {},
    checkout: {
        step: 0,
        phone: '',
        generatedOTP: '',
        isVerified: false
    }
};

const N8N_WEBHOOK_URL = 'https://elyamanipron8n.elyamanipron8n.cfd/webhook/a0070ead-b9f2-4c70-af07-ba1245d39d30';

lucide.createIcons();

// --- APP CONTROLLER ---
const app = {
    
    init() {
        setTimeout(() => {
            document.getElementById('loader').style.opacity = '0';
            setTimeout(() => {
                document.getElementById('loader').style.display = 'none';
            }, 800);
        }, 1500);

        this.renderProductsGrid();
        this.startCardAutoSliders();
        
        window.addEventListener('scroll', () => {
            const nav = document.getElementById('navbar');
            if (window.scrollY > 50) nav.classList.add('scrolled');
            else nav.classList.remove('scrolled');
        });

        // Initialize view based on hash if present, or home
        const initialHash = window.location.hash.replace('#', '');
        if (['home', 'whyus', 'product'].includes(initialHash)) {
            if (initialHash !== 'product') this.navigateTo(initialHash, false);
        } else if (initialHash === 'collection') {
            this.navigateTo('home', false);
            setTimeout(() => this.scrollToCollection(), 200);
        }

        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.view) {
                this.navigateTo(e.state.view, false);
            } else {
                this.navigateTo('home', false);
            }
        });
    },

    // UI Utilities
    toggleMenu() {
        if (state.cartOpen) this.toggleCart();
        state.menuOpen = !state.menuOpen;
        const menu = document.getElementById('side-menu');
        const overlay = document.getElementById('menu-overlay');
        
        if (state.menuOpen) { menu.classList.add('open'); overlay.classList.add('open'); } 
        else { menu.classList.remove('open'); overlay.classList.remove('open'); }
    },

    toggleCart() {
        if (state.menuOpen) this.toggleMenu();
        state.cartOpen = !state.cartOpen;
        const cart = document.getElementById('cart-drawer');
        const overlay = document.getElementById('menu-overlay');
        
        if (state.cartOpen) { cart.classList.add('open'); overlay.classList.add('open'); } 
        else { cart.classList.remove('open'); overlay.classList.remove('open'); }
    },

    closeAllDrawers() {
        if (state.menuOpen) this.toggleMenu();
        if (state.cartOpen) this.toggleCart();
    },

    navigateTo(viewId, pushHistory = true) {
        // Handle views
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById(`view-${viewId}`).classList.add('active');
        window.scrollTo(0, 0);
        state.currentView = viewId;
        
        // Clear main slider if we navigate away
        if (viewId !== 'product' && state.sliderInterval) {
            clearInterval(state.sliderInterval);
            state.sliderInterval = null;
        }

        if (pushHistory) {
            window.history.pushState({ view: viewId }, viewId, `#${viewId}`);
        }
    },
    
    goBack() {
        // Try native back button. If there's no history, just go to home
        if (window.history.state !== null) {
            window.history.back();
        } else {
            this.navigateTo('home');
        }
    },

    scrollToCollection() {
        const collection = document.getElementById('collection-section');
        const navHeight = document.getElementById('navbar').offsetHeight;
        window.scrollTo({
            top: collection.offsetTop - navHeight,
            behavior: 'smooth'
        });
    },

    renderProductsGrid() {
        const grid = document.getElementById('product-grid');
        grid.innerHTML = '';
        
        PRODUCTS.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.onclick = () => this.openProduct(product.id);
            
            card.innerHTML = `
                <div class="product-image-wrapper">
                    <img id="grid-img-${product.id}" src="${product.images[0]}" alt="${product.name}" loading="lazy">
                </div>
                <div class="product-info-card">
                    <h3 class="product-title">${product.name}</h3>
                    <div class="product-price-row">
                        <span class="price-current">${product.price_current} DH</span>
                        <span class="price-old">${product.price_old} DH</span>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    },

    openProduct(productId) {
        const product = PRODUCTS.find(p => p.id === productId);
        if (!product) return;
        
        state.activeProduct = product;
        state.galleryIndex = 0;
        state.selectedSize = null;
        
        document.querySelectorAll('.size-btn').forEach(btn => btn.classList.remove('selected'));
        document.getElementById('size-error').style.display = 'none';
        
        document.getElementById('pd-title').innerText = product.name;
        document.getElementById('pd-price').innerText = `${product.price_current} DH`;
        document.getElementById('pd-price-old').innerText = `${product.price_old} DH`;
        document.querySelector('.pd-description').innerText = product.description;
        
        this.updateGalleryUI();
        this.startMainProductSlider();
        this.navigateTo('product');
    },

    startMainProductSlider() {
        if (state.sliderInterval) clearInterval(state.sliderInterval);
        state.sliderInterval = setInterval(() => {
            this.nextImage();
        }, 3000);
    },

    startCardAutoSliders() {
        PRODUCTS.forEach(product => {
            let idx = 0;
            state.cardIntervals[product.id] = setInterval(() => {
                idx = (idx + 1) % product.images.length;
                const imgEl = document.getElementById(`grid-img-${product.id}`);
                if (imgEl) {
                    imgEl.src = product.images[idx];
                }
            }, 3500 + Math.random() * 1000); // Stagger timings slightly
        });
    },

    updateGalleryUI() {
        const product = state.activeProduct;
        document.getElementById('pd-main-image').src = product.images[state.galleryIndex];
        
        const thumbContainer = document.getElementById('pd-thumbnails');
        thumbContainer.innerHTML = '';
        product.images.forEach((imgSrc, idx) => {
            const img = document.createElement('img');
            img.src = imgSrc;
            img.className = `thumbnail-img ${idx === state.galleryIndex ? 'active' : ''}`;
            img.onclick = () => {
                state.galleryIndex = idx;
                this.updateGalleryUI();
                // Reset timer on manual interaction
                this.startMainProductSlider();
            };
            thumbContainer.appendChild(img);
        });
    },
    
    prevImage() {
        if (!state.activeProduct) return;
        const total = state.activeProduct.images.length;
        state.galleryIndex = (state.galleryIndex - 1 + total) % total;
        this.updateGalleryUI();
        // Reset timer on manual click from UI
        if(event && event.type === 'click') this.startMainProductSlider();
    },
    nextImage(event) {
        if (!state.activeProduct) return;
        const total = state.activeProduct.images.length;
        state.galleryIndex = (state.galleryIndex + 1) % total;
        this.updateGalleryUI();
        // Reset timer on manual click from UI
        if(event && event.type === 'click') this.startMainProductSlider();
    },

    selectSize(size) {
        state.selectedSize = size;
        document.getElementById('size-error').style.display = 'none';
        document.querySelectorAll('.size-btn').forEach(btn => {
            if (btn.innerText === size) btn.classList.add('selected');
            else btn.classList.remove('selected');
        });
    },

    addToCart() {
        if (!state.selectedSize) {
            document.getElementById('size-error').style.display = 'block';
            return;
        }

        const item = {
            id: state.activeProduct.id + '-' + state.selectedSize,
            product: state.activeProduct,
            size: state.selectedSize,
            quantity: 1
        };

        const existingItem = state.cart.find(i => i.id === item.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            state.cart.push(item);
        }

        this.updateCartUI();
        this.toggleCart();
    },

    removeFromCart(itemId) {
        state.cart = state.cart.filter(i => i.id !== itemId);
        this.updateCartUI();
    },

    updateCartUI() {
        const countEl = document.getElementById('cart-count');
        const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
        countEl.innerText = count;
        if (count > 0) countEl.classList.add('visible');
        else countEl.classList.remove('visible');

        const container = document.getElementById('cart-items-container');
        if (state.cart.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #666; margin-top: 2rem;">Votre panier est vide.</p>';
            document.getElementById('cart-total-price').innerText = '0 DH';
            return;
        }

        let html = '';
        let total = 0;
        state.cart.forEach(item => {
            const itemTotal = item.product.price_current * item.quantity;
            total += itemTotal;
            html += `
                <div class="cart-item">
                    <img src="${item.product.images[0]}" class="cart-item-img">
                    <div class="cart-item-details">
                        <div class="cart-item-title">${item.product.name}</div>
                        <div class="cart-item-size">Taille: ${item.size} | Qté: ${item.quantity}</div>
                        <div class="cart-item-price">${itemTotal} DH</div>
                        <button class="cart-item-remove" onclick="app.removeFromCart('${item.id}')">Retirer</button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
        document.getElementById('cart-total-price').innerText = `${total} DH`;
    },

    startDirectCheckout() {
        if (!state.selectedSize) {
            document.getElementById('size-error').style.display = 'block';
            return;
        }
        state.checkoutMode = 'direct';
        state.checkout = { step: 1, phone: '', generatedOTP: '', isVerified: false };
        this.updateCheckoutModalUI();
        document.getElementById('checkout-modal').classList.add('open');
    },

    startCartCheckout() {
        if (state.cart.length === 0) return;
        state.checkoutMode = 'cart';
        this.toggleCart();
        state.checkout = { step: 1, phone: '', generatedOTP: '', isVerified: false };
        this.updateCheckoutModalUI();
        document.getElementById('checkout-modal').classList.add('open');
    },
    
    closeModal() {
        if (state.checkout.step === 4) return;
        document.getElementById('checkout-modal').classList.remove('open');
    },

    closeModalAndReset() {
        document.getElementById('checkout-modal').classList.remove('open');
        setTimeout(() => this.navigateTo('home'), 300);
    },

    updateCheckoutModalUI() {
        document.querySelectorAll('.checkout-step').forEach(s => s.classList.remove('active'));
        document.getElementById(`step-${state.checkout.step}`).classList.add('active');
        
        const title = document.getElementById('modal-title');
        if (state.checkout.step === 1) title.innerText = 'Vérification (1/3)';
        if (state.checkout.step === 2) title.innerText = 'Code OTP (2/3)';
        if (state.checkout.step === 3) {
            title.innerText = 'Livraison (3/3)';
            // Update submit button text with correct price
            let total = 0;
            if (state.checkoutMode === 'direct') {
                total = state.activeProduct.price_current;
            } else {
                total = state.cart.reduce((sum, item) => sum + (item.product.price_current * item.quantity), 0);
            }
            document.getElementById('btn-submit-order').innerText = `Confirmer la commande (${total} DH)`;
        }
        if (state.checkout.step === 4) title.innerText = 'Succès !';
    },

    async _sendWebhookRequest(payload) {
        try {
            document.getElementById('modal-loader').style.display = 'flex';
            const response = await fetch(N8N_WEBHOOK_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            document.getElementById('modal-loader').style.display = 'none';
            if (!response.ok) throw new Error('Network error');
            return true;
        } catch (err) {
            document.getElementById('modal-loader').style.display = 'none';
            console.error('Webhook Error:', err);
            return true; 
        }
    },

    async requestOTP() {
        const phoneInput = document.getElementById('checkout-phone').value.trim();
        if (phoneInput.length < 9) {
            alert('Veuillez entrer un numéro de téléphone valide (ex: 612345678)');
            return;
        }
        
        let cleanedFormat = phoneInput;
        if (phoneInput.startsWith('0')) cleanedFormat = phoneInput.substring(1);
        
        state.checkout.phone = '212' + cleanedFormat;
        state.checkout.generatedOTP = Math.floor(1000 + Math.random() * 9000).toString();
        
        console.log(`[DEV ONLY] Webhook action: send_otp, Phone: ${state.checkout.phone}, OTP: ${state.checkout.generatedOTP}`);
        await this._sendWebhookRequest({ action: 'send_otp', phone: state.checkout.phone, otp: state.checkout.generatedOTP });

        state.checkout.step = 2;
        this.updateCheckoutModalUI();
    },

    verifyOTP() {
        const inputOtp = document.getElementById('checkout-otp').value.trim();
        const errorEl = document.getElementById('otp-error');
        
        if (inputOtp === state.checkout.generatedOTP) {
            errorEl.style.display = 'none';
            state.checkout.isVerified = true;
            state.checkout.step = 3;
            this.updateCheckoutModalUI();
        } else {
            errorEl.style.display = 'block';
        }
    },

    async submitOrder() {
        const nom = document.getElementById('checkout-nom').value.trim();
        const ville = document.getElementById('checkout-ville').value;
        const adresse = document.getElementById('checkout-adresse').value.trim();
        const textQuestion = document.getElementById('checkout-text').value.trim();

        if (!nom || !ville || !adresse) {
            alert("Veuillez remplir tous les champs de livraison.");
            return;
        }

        let modeleStr = '';
        let tailleStr = '';
        let productNameStr = '';
        let quantityStr = '';
        
        if (state.checkoutMode === 'direct') {
            modeleStr = state.activeProduct.name;
            tailleStr = state.selectedSize;
            productNameStr = state.activeProduct.name;
            quantityStr = "1";
        } else {
            modeleStr = state.cart.map(item => `${item.product.name} (x${item.quantity})`).join(', ');
            tailleStr = state.cart.map(item => item.size).join(', ');
            productNameStr = state.cart.map(item => item.product.name).join(', ');
            quantityStr = state.cart.map(item => item.quantity).join(', ');
        }

        const orderDate = new Date().toLocaleString('fr-FR', { timeZone: 'Africa/Casablanca' });

        const payload = {
            action: 'order',
            client: `CLIENT-${Math.floor(Math.random()*10000)}`,
            nom: nom,
            tel: state.checkout.phone,
            ville: ville,
            adresse: adresse,
            "modéle nom": modeleStr,
            taille: tailleStr,
            "product": productNameStr,
            "quantity": quantityStr,
            "question": textQuestion,
            "date": orderDate
        };

        console.log("[DEV ONLY] Submitting final order to n8n:", payload);
        await this._sendWebhookRequest(payload);

        if (state.checkoutMode === 'cart') {
            state.cart = [];
            this.updateCartUI();
        }

        state.checkout.step = 4;
        this.updateCheckoutModalUI();
    }
};

document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
